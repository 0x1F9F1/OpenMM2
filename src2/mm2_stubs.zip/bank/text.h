/*
    OpenMM1 - An Open Source Re-Implementation of Midtown Madness 2
    Copyright (C) 2020 0x1F9F1

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

/*
    bank:text

    public: __thiscall bkText::bkText(class bkBank &,char const *,char *,unsigned int,bool,class datCallback) | ??0bkText@@QAE@AAVbkBank@@PBDPADI_NVdatCallback@@@Z
    public: virtual __thiscall bkText::~bkText(void) | ??1bkText@@UAE@XZ
    public: virtual void * __thiscall bkText::`vector deleting destructor'(unsigned int) | ??_EbkText@@UAEPAXI@Z
    public: virtual void * __thiscall bkText::`scalar deleting destructor'(unsigned int) | ??_GbkText@@UAEPAXI@Z
    public: virtual void __thiscall bkText::SetText(char const *) | ?SetText@bkText@@UAEXPBD@Z
    const bkText::`vftable'{for `bkWidget'} | ??_7bkText@@6BbkWidget@@@
    const bkText::`vftable'{for `bkText'} | ??_7bkText@@6B0@@
    const bkText::`vbtable' | ??_8bkText@@7B@
*/
